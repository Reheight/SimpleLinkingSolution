import "./App.css";
import background from "./background.png";
import APIHandler from "./lib/APIHandler";
import { useEffect, useState } from "react";

const API = new APIHandler(
  process.env.REACT_APP_LINKING_API_URI,
  process.env.REACT_APP_LINKING_API_PORT
);

function getState(initiated, API_DATA, USER_DATA) {
  if (!initiated) return <div className="loader" />;

  if (!USER_DATA.Exists)
    return (
      <div className="elements-login">
        <a
          className="option incomplete"
          href={`${process.env.REACT_APP_LINKING_API_URI}:${process.env.REACT_APP_LINKING_API_PORT}/api/authentication/steam`}
        >
          Login with Steam
        </a>
      </div>
    );

  return (
    <div className="elements">
      <div
        className={`option ${
          USER_DATA.Exists && USER_DATA.SteamID ? "complete" : "incomplete"
        }`}
        onClick={() => {
          if (!USER_DATA.Exists || !USER_DATA.SteamID)
            return window.open(
              `${process.env.REACT_APP_LINKING_API_URI}:${process.env.REACT_APP_LINKING_API_PORT}/api/authentication/steam`,
              "_blank"
            );
        }}
      >
        Link Steam&nbsp;
        {USER_DATA.Exists && USER_DATA.SteamID ? (
          <i class="fas fa-check"></i>
        ) : (
          <i class="fas fa-times"></i>
        )}
      </div>

      {API_DATA.CheckSteamGroup ? (
        <div
          className={`option ${
            USER_DATA.InSteamGroup ? "complete" : "incomplete"
          }`}
          onClick={() => {
            if (!USER_DATA.InSteamGroup)
              return window.open(
                `https://steamcommunity.com/groups/${API_DATA.SteamGroupID}`,
                "_blank"
              );
          }}
        >
          Steam Group&nbsp;
          {USER_DATA.InSteamGroup ? (
            <i class="fas fa-check"></i>
          ) : (
            <i class="fas fa-times"></i>
          )}
        </div>
      ) : (
        <></>
      )}

      <div
        className={`option ${
          USER_DATA.DiscordAssociated ? "complete" : "incomplete"
        }`}
        onClick={() => {
          if (!USER_DATA.DiscordAssociated)
            return window.open(
              `${process.env.REACT_APP_LINKING_API_URI}:${process.env.REACT_APP_LINKING_API_PORT}/api/authentication/discord`
            );
        }}
      >
        Link Discord&nbsp;
        {USER_DATA.DiscordAssociated ? (
          <i class="fas fa-check"></i>
        ) : (
          <i class="fas fa-times"></i>
        )}
      </div>

      {API_DATA.CheckDiscordServer ? (
        <div
          className={`option ${
            USER_DATA.InDiscordServer ? "complete" : "incomplete"
          }`}
          onClick={() => {
            if (!USER_DATA.InDiscordServer)
              return window.open(
                `https://discord.gg/${API_DATA.DiscordInviteCode}`,
                "_blank"
              );
          }}
        >
          Discord Server&nbsp;
          {USER_DATA.InDiscordServer ? (
            <i class="fas fa-check"></i>
          ) : (
            <i class="fas fa-times"></i>
          )}
        </div>
      ) : (
        <></>
      )}

      {API_DATA.CheckDiscordServer ? (
        <div
          className={`option ${
            USER_DATA.IsBoostingDiscord ? "complete" : "incomplete"
          }`}
          onClick={() => {
            if (!USER_DATA.IsBoostingDiscord)
              return window.open(
                `https://discord.gg/${API_DATA.DiscordInviteCode}`,
                "_blank"
              );
          }}
        >
          Boosting Discord&nbsp;
          {USER_DATA.IsBoostingDiscord ? (
            <i class="fas fa-check"></i>
          ) : (
            <i class="fas fa-times"></i>
          )}
        </div>
      ) : (
        <></>
      )}
    </div>
  );
}

function App() {
  const [wAPI_DATA, setWAPI_DATA] = useState({});
  const [wUSER_DATA, setWUSER_DATA] = useState({});
  const [initiated, setInitiated] = useState(false);

  useEffect(() => {
    async function initiate() {
      const API_DATA = await API.APIRequest("options");
      const USER_DATA = await API.APIRequest("fetch");

      if (!initiated) setInitiated(true);

      if (wAPI_DATA !== API_DATA) setWAPI_DATA(API_DATA);

      if (wUSER_DATA !== USER_DATA) setWUSER_DATA(USER_DATA);
    }

    setInterval(async () => {
      await initiate();
    }, 5000);

    initiate();
  }, []);

  return (
    <div className="application">
      <div className="background" />
      <div className="content-container">
        <div className="inner-container logo-box content-header">
          <h1 className="header-text">Website</h1>
        </div>
        <div className="inner-container status-box" id="controller">
          {getState(initiated, wAPI_DATA, wUSER_DATA)}
        </div>
      </div>
    </div>
  );
}

export default App;
